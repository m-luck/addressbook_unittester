### Using JUnit4

The unit tests are separated to target each class. 

The file AllTests.java is just the combination of the two test classes in order to make running (and coverage information) easier. It is optional and just for the assignment. 
